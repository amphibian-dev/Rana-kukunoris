# Rana-kukunoris
R tools for building credit scorecards

![logo](image/rana-kuku.png)